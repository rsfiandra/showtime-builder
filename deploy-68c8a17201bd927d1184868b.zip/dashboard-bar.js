// Dashboard Bar (Tabbed Version)
//
// This variant of the dashboard widget presents summary charts in a fixed‑height
// bar at the bottom of every page.  Rather than displaying all charts at
// once, the widget uses tabs to switch between four views: shows by film,
// shows by auditorium, start/end time distribution, and utilisation & issues.
// Each tab contains a chart rendered with Chart.js.  Limiting the number
// of categories prevents the charts from growing indefinitely and keeps
// the widget compact.  The bar height is fixed so that no internal
// scrolling occurs, and the body’s bottom padding is adjusted dynamically
// whenever the bar opens or its contents update.

(function() {
  const ShowtimeState = window.ShowtimeState;
  if (!ShowtimeState) return;

  // Persist dashboard bar open state across page navigations. Use a
  // dedicated key in localStorage to remember whether the bar was
  // previously open. When the bar is shown or hidden via the toggle
  // button, we update this key accordingly. On page load, we read
  // this key and re‑open the bar if needed. Choosing a namespaced
  // key avoids collisions with other modules.
  const DASHBAR_OPEN_KEY = 'showtime:dashboardBarOpen';

  // Persist the last selected dashboard tab across page loads.  When the user
  // switches tabs within the dashboard bar, we record the id of the active
  // tab in localStorage under this key.  On page load, we restore the
  // previously selected tab.  Namespacing avoids collisions with other
  // modules.
  const DASHBAR_TAB_KEY = 'showtime:dashboardBarTab';

  // Chart instances (one per tab)
  let filmChart = null;
  let audChart = null;
  let timeChart = null;
  let utilChart = null;

  // Maximum number of categories to display in bar charts.  Additional
  // categories are aggregated into an "Other" bar.
  const MAX_BAR_CATEGORIES = 8;

  // Threshold constants for downtime and late‑first flagging.  These values
  // mirror those used on the dedicated dashboard page.  A gap shorter
  // than GAP_THRESHOLD_MIN minutes is ignored; a gap equal or above
  // GAP_HUGE_MIN is considered a huge gap.  FIT_SLOT_MIN defines the
  // minimum duration between the operating window start and the first show
  // that constitutes a late‑first slot.
  const GAP_THRESHOLD_MIN = 45;
  const GAP_HUGE_MIN = 90;
  const FIT_SLOT_MIN = 105;

  /**
   * Dynamically load Chart.js if it hasn’t been loaded already.  Returns a
   * Promise that resolves once the library is available.  Loading from a
   * CDN ensures the page isn’t weighed down by unused scripts until
   * necessary.
   */
  function loadChartJs() {
    return new Promise(resolve => {
      if (window.Chart) {
        resolve();
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      script.onload = () => resolve();
      script.onerror = () => {
        console.error('Failed to load Chart.js from CDN');
        resolve();
      };
      document.head.appendChild(script);
    });
  }

  /**
   * Convert a 24‑hour integer into a human‑friendly 12‑hour label.
   * Example: 0 -> 12a, 13 -> 1p.
   * @param {number} h  Hour of day (0–23)
   * @returns {string}
   */
  function formatHour(h) {
    const hour12 = ((h + 11) % 12) + 1;
    return hour12 + (h < 12 ? 'a' : 'p');
  }

  /**
   * Compute shows and seats grouped by hour as well as by end hour.  The
   * returned object contains labels (hours), start counts, end counts and
   * total seat counts per hour.  Hours with no shows are included to
   * maintain consistent ordering.
   */
  function computeTimeDistribution(shows) {
    const startCounts = {};
    const endCounts = {};
    const seatCounts = {};
    shows.forEach(rec => {
      // Normalise start time to ensure it’s a Date
      const start = rec.start instanceof Date ? rec.start : new Date(rec.start);
      const sh = start.getHours();
      startCounts[sh] = (startCounts[sh] || 0) + 1;
      // Seats per start hour
      let seats = 0;
      try {
        const audId = rec.audId;
        if (ShowtimeState.audById && audId != null) {
          const audObj = ShowtimeState.audById(audId);
          seats = audObj && audObj.seats != null ? parseInt(audObj.seats, 10) || 0 : 0;
        }
      } catch (_) {
        seats = 0;
      }
      seatCounts[sh] = (seatCounts[sh] || 0) + seats;
      // Normalise end time (may be missing)
      let end = rec.end;
      if (!end || !(end instanceof Date)) {
        let film = null;
        if (rec.filmId && ShowtimeState.filmById) {
          try { film = ShowtimeState.filmById(rec.filmId); } catch (_) { film = null; }
        }
        if (film) {
          const total = (film.runtime || 0) + (film.trailer || 0) + (film.clean || 0);
          end = new Date(start.getTime() + total * 60000);
        } else {
          end = new Date(start);
        }
      }
      const eh = end.getHours();
      endCounts[eh] = (endCounts[eh] || 0) + 1;
    });
    // Build ordered arrays for 24 hours (0–23).  This ensures the x‑axis
    // ordering is consistent even if there are no shows in some hours.
    const labels = [];
    const starts = [];
    const ends = [];
    const seats = [];
    for (let h = 0; h < 24; h++) {
      labels.push(formatHour(h));
      starts.push(startCounts[h] || 0);
      ends.push(endCounts[h] || 0);
      seats.push(seatCounts[h] || 0);
    }
    return { labels, starts, ends, seats };
  }

  /**
   * Compute flagged issues across all auditoriums.  Issues include
   * late‑first slots and gaps (normal and huge).  Returns a count of
   * issues by type.  This function mirrors the logic used on the
   * dedicated dashboard page but summarises counts rather than listing
   * each gap individually.
   */
  function computeFlaggedCounts(shows) {
    const GAP_THRESHOLD_MIN = 45;
    const GAP_HUGE_MIN = 90;
    const FIT_SLOT_MIN = 105;
    const byAud = {};
    shows.forEach(rec => {
      const audId = rec.audId;
      if (!audId) return;
      if (!byAud[audId]) byAud[audId] = [];
      // Determine end time; compute fallback if missing
      let endDate = rec.end;
      if (!endDate) {
        let film = null;
        if (rec.filmId && ShowtimeState.filmById) {
          try { film = ShowtimeState.filmById(rec.filmId); } catch (_) { film = null; }
        }
        if (film) {
          const total = (film.runtime || 0) + (film.trailer || 0) + (film.clean || 0);
          endDate = new Date(rec.start.getTime() + total * 60000);
        } else {
          endDate = new Date(rec.start);
        }
      }
      byAud[audId].push({ start: rec.start instanceof Date ? rec.start : new Date(rec.start), end: endDate });
    });
    const counts = { late: 0, gap: 0, huge: 0 };
    // Determine operating window start per auditorium from state
    const state = ShowtimeState.state || {};
    const dateIso = ShowtimeState.getCurrentDate && ShowtimeState.getCurrentDate();
    let globalFirstHM = (state && state.firstShowHM) || '07:00';
    if (dateIso && state.scheduleByDate && state.scheduleByDate[dateIso]) {
      globalFirstHM = state.scheduleByDate[dateIso].firstShowHM || globalFirstHM;
    }
    Object.keys(byAud).forEach(audId => {
      const list = byAud[audId];
      list.sort((a,b) => a.start - b.start);
      const windowStart = ShowtimeState.dtFromHM ? ShowtimeState.dtFromHM(globalFirstHM) : new Date();
      const firstStart = list[0].start;
      const diffFirst = (firstStart - windowStart) / 60000;
      if (diffFirst >= FIT_SLOT_MIN) counts.late++;
      for (let i = 0; i < list.length - 1; i++) {
        const gapMin = (list[i + 1].start - list[i].end) / 60000;
        if (gapMin >= GAP_THRESHOLD_MIN) {
          counts[gapMin >= GAP_HUGE_MIN ? 'huge' : 'gap']++;
        }
      }
    });
    return counts;
  }

  /**
   * Lighten a colour by a given percentage. Accepts a hex string (e.g. "#123abc")
   * and returns a new hex string.  Used by the mini Gantt timeline to generate
   * gradients for show bars.  If a CSS variable is passed (e.g. "var(--brand-from)"),
   * it will be resolved using getComputedStyle on the document element.
   *
   * @param {string} hex  Colour to lighten
   * @param {number} percent  Percentage between 0 and 100
   * @returns {string}
   */
  function lightenColor(hex, percent) {
    if (!hex) return hex;
    // Resolve CSS variables to hex values
    if (hex.startsWith('var(')) {
      const m = /--[^)]+/.exec(hex);
      if (m) {
        const val = getComputedStyle(document.documentElement).getPropertyValue(m[0]).trim();
        if (val) hex = val;
      }
    }
    // Remove '#' and normalise length
    const h = hex.replace('#','');
    if (h.length !== 6) return hex;
    const r = parseInt(h.substring(0,2), 16);
    const g = parseInt(h.substring(2,4), 16);
    const b = parseInt(h.substring(4,6), 16);
    const nr = Math.min(255, Math.round(r + (255 - r) * percent / 100));
    const ng = Math.min(255, Math.round(g + (255 - g) * percent / 100));
    const nb = Math.min(255, Math.round(b + (255 - b) * percent / 100));
    return '#' + [nr,ng,nb].map(x => x.toString(16).padStart(2,'0')).join('');
  }

  /**
   * Render a compact Gantt timeline inside the dashboard bar.  This function
   * uses the provided list of show records to build a small timeline by
   * grouping shows by auditorium and computing start and end times.  The
   * output is appended to the panel with id "dashboardTabPanel-gantt".  If
   * no shows are available or end times cannot be determined, a message
   * is displayed instead.  Colours reflect occupancy: high occupancy bars
   * are red, medium occupancy bars are orange and others use the brand
   * colour gradient.
   *
   * @param {Array} shows  Array of show records from ShowtimeState.getAllShows()
   */
  function renderMiniGantt(shows) {
    const container = document.getElementById('dashboardTabPanel-gantt');
    if (!container) return;
    // Clear previous content
    container.innerHTML = '';
    // Ensure container scrolls horizontally if needed
    container.style.overflowX = 'auto';
    container.style.position = 'relative';
    // Guard against empty dataset
    if (!shows || shows.length === 0) {
      const p = document.createElement('p');
      p.textContent = 'No shows loaded.';
      container.appendChild(p);
      return;
    }
    // Precompute show start and end times.  If rec.end is missing, infer
    // using film runtime, trailer and clean times.  Default to 2h if
    // nothing is available.
    const showsWithEnd = [];
    shows.forEach(rec => {
      // Normalise start
      let start = rec.start;
      if (!(start instanceof Date)) {
        start = new Date(start);
      }
      if (!start) return;
      let end = rec.end;
      if (!end || !(end instanceof Date)) {
        let film = null;
        if (rec.filmId && ShowtimeState.filmById) {
          try {
            film = ShowtimeState.filmById(rec.filmId);
          } catch (_) {
            film = null;
          }
        }
        if (film) {
          const total = (film.runtime || 0) + (film.trailer || 0) + (film.clean || 0);
          if (total && !isNaN(total)) {
            end = new Date(start.getTime() + total * 60000);
          }
        }
        if (!end) {
          // Fallback to 120 minutes duration
          end = new Date(start.getTime() + 120 * 60000);
        }
      }
      showsWithEnd.push({ rec, start, end });
    });
    if (!showsWithEnd.length) {
      const p = document.createElement('p');
      p.textContent = 'End times not provided; Gantt unavailable.';
      container.appendChild(p);
      return;
    }
    // Determine timeline range (hours).  Extend to full hour boundaries.
    let minStart = Infinity;
    let maxEnd   = -Infinity;
    showsWithEnd.forEach(obj => {
      const s = obj.start.getHours() + obj.start.getMinutes() / 60;
      const e = obj.end.getHours() + obj.end.getMinutes() / 60;
      if (s < minStart) minStart = s;
      if (e > maxEnd)   maxEnd   = e;
    });
    // Baseline: start at the earlier of first show and 9AM; end at the later
    // of last show and midnight.  Using Math.floor/ceil ensures bars align
    // on hour boundaries.
    const startHour = Math.floor(Math.min(minStart, 9));
    const endHour   = Math.ceil(Math.max(maxEnd, 24));
    const hours     = endHour - startHour;
    // Determine pixel width per hour.  Use a baseline of 40px per hour
    // but expand if container width allows.  Subtract 60px for the label
    // column.  If container width is zero (not yet rendered), default to 40px.
    let pxPerHour = 40;
    const availableWidth = container.clientWidth - 60;
    if (availableWidth > hours * 40) {
      pxPerHour = availableWidth / hours;
    }
    const pxPerMin  = pxPerHour / 60;
    const totalWidth = hours * pxPerHour;
    // Build header row with hour labels
    const headerRow = document.createElement('div');
    headerRow.style.display = 'flex';
    headerRow.style.alignItems = 'center';
    headerRow.style.height = '28px';
    headerRow.style.fontSize = '0.7rem';
    // Blank cell for auditorium labels
    const blank = document.createElement('div');
    blank.style.width = '60px';
    blank.style.background = 'var(--brand-from)';
    headerRow.appendChild(blank);
    for (let h = startHour; h < endHour; h++) {
      const cell = document.createElement('div');
      cell.style.flex = '0 0 ' + pxPerHour + 'px';
      cell.style.borderLeft = '1px solid rgba(255,255,255,0.3)';
      cell.style.background = 'var(--brand-from)';
      cell.style.color = '#ffffff';
      cell.style.display = 'flex';
      cell.style.alignItems = 'center';
      cell.style.justifyContent = 'center';
      const hr  = ((h + 11) % 12) + 1;
      const ampm = h % 24 < 12 ? 'a' : 'p';
      cell.textContent = hr + ampm;
      headerRow.appendChild(cell);
    }
    container.appendChild(headerRow);
    // Group shows by auditorium name
    const byAud = {};
    showsWithEnd.forEach(obj => {
      const name = obj.rec.audName || 'Aud';
      if (!byAud[name]) byAud[name] = [];
      byAud[name].push(obj);
    });
    const audNames = Object.keys(byAud).sort((a,b) => {
      // Sort numerically if names contain numbers (e.g. Aud 1, Aud 2)
      const ra = /\d+/.exec(a);
      const rb = /\d+/.exec(b);
      if (ra && rb) {
        const na = parseInt(ra[0], 10);
        const nb = parseInt(rb[0], 10);
        if (na !== nb) return na - nb;
      }
      return a.localeCompare(b);
    });
    // Sort shows within each auditorium by start time
    audNames.forEach(name => byAud[name].sort((a,b) => a.start - b.start));
    // Determine base brand colour and occupancy thresholds
    const rootStyle = getComputedStyle(document.documentElement);
    let brandColor = rootStyle.getPropertyValue('--brand-from').trim() || '#3b82f6';
    const OCC_HIGH = 1.0;
    const OCC_MID  = 0.85;
    // Build a row for each auditorium
    audNames.forEach(name => {
      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.alignItems = 'center';
      row.style.position = 'relative';
      row.style.height = '28px';
      // Auditorium label
      const lab = document.createElement('div');
      lab.style.width = '60px';
      lab.style.fontSize = '0.7rem';
      lab.style.overflow = 'hidden';
      lab.style.whiteSpace = 'nowrap';
      lab.style.textOverflow = 'ellipsis';
      lab.style.paddingRight = '4px';
      lab.textContent = name;
      row.appendChild(lab);
      // Content area
      const content = document.createElement('div');
      content.style.position = 'relative';
      content.style.height = '24px';
      content.style.width = totalWidth + 'px';
      // Create bars for each show
      byAud[name].forEach(obj => {
        const startMin    = ((obj.start.getHours() + obj.start.getMinutes()/60) - startHour) * 60;
        const durationMin = (obj.end - obj.start) / 60000;
        const bar = document.createElement('div');
        bar.style.position = 'absolute';
        bar.style.left = (startMin * pxPerMin) + 'px';
        bar.style.width = (durationMin * pxPerMin) + 'px';
        bar.style.height = '20px';
        bar.style.borderRadius = '4px';
        bar.style.display = 'flex';
        bar.style.alignItems = 'center';
        bar.style.fontSize = '0.6rem';
        bar.style.whiteSpace = 'nowrap';
        bar.style.overflow = 'hidden';
        bar.style.textOverflow = 'ellipsis';
        bar.style.paddingLeft = '2px';
        // Determine occupancy
        let occ = null;
        if (typeof obj.rec.occupancy === 'number') {
          occ = obj.rec.occupancy;
        } else {
          // Compute occupancy using attendance and auditorium seats
          try {
            const audId = obj.rec.audId;
            const audObj = ShowtimeState.audById ? ShowtimeState.audById(audId) : null;
            const seats  = audObj && audObj.seats != null ? parseInt(audObj.seats, 10) || 0 : 0;
            const attend = parseFloat(obj.rec.attendance) || 0;
            if (seats > 0) occ = attend / seats;
          } catch (_) {}
        }
        // Base colour: brand gradient
        let baseColor = brandColor;
        if (occ != null && !isNaN(occ)) {
          if (occ >= OCC_HIGH) {
            baseColor = '#ef4444'; // red for 100%+ occupancy
          } else if (occ >= OCC_MID) {
            baseColor = '#f59e0b'; // amber for mid occupancy
          }
        }
        const lightColor = lightenColor(baseColor, 50);
        bar.style.backgroundImage = `linear-gradient(to right, ${lightColor}, ${baseColor})`;
        bar.style.color = '#ffffff';
        const titleParts = [];
        if (obj.rec.filmTitle) titleParts.push(obj.rec.filmTitle);
        if (obj.rec.audName) titleParts.push(obj.rec.audName);
        const startStr = obj.start.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
        const endStr   = obj.end.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
        titleParts.push(`${startStr} – ${endStr}`);
        if (occ != null && !isNaN(occ)) titleParts.push('Occupancy: ' + Math.round(occ * 100) + '%');
        bar.title = titleParts.join('\n');
        bar.textContent = obj.rec.filmTitle || '';
        content.appendChild(bar);
      });
      row.appendChild(content);
      container.appendChild(row);
    });
  }

  /**
   * Normalize a date so that times before 5AM are considered part of the next day.
   * Mirrors the logic used in the dedicated dashboard page and schedule grid.
   *
   * @param {Date} dt
   * @returns {Date}
   */
  function normalizeDateForGap(dt) {
    const n = new Date(dt);
    if (n.getHours() < 5) {
      n.setDate(n.getDate() + 1);
    }
    return n;
  }

  /**
   * Format a duration in minutes into an HhMMm string (e.g. 1h30m).
   *
   * @param {number} mins
   * @returns {string}
   */
  function formatDuration(mins) {
    const h = Math.floor(mins / 60);
    const m = Math.round(mins % 60);
    return `${h}h${String(m).padStart(2, '0')}m`;
  }

  /**
   * Compute a detailed list of flagged issues (downtime gaps and late‑first slots)
   * for the current schedule.  Returns an array of objects with auditorium name,
   * type (late, gap, huge), descriptive message and gap duration in minutes.
   *
   * This mirrors the logic on the dedicated dashboard page.
   *
   * @param {Array} shows
   * @returns {Array<{audName: string, type: string, message: string, minutes: number}>}
   */
  function computeFlaggedIssues(shows) {
    const issues = [];
    if (!shows || !shows.length) return issues;
    const byAud = {};
    // Group shows by auditorium ID and compute end times if missing
    shows.forEach(rec => {
      const audId = rec.audId;
      if (!audId) return;
      if (!byAud[audId]) byAud[audId] = [];
      let endDate = rec.end;
      if (!endDate) {
        // Compute end based on film runtime, trailer and clean durations
        let film = null;
        if (rec.filmId && ShowtimeState.filmById) {
          try { film = ShowtimeState.filmById(rec.filmId); } catch (_) { film = null; }
        }
        if (film) {
          const total = (film.runtime || 0) + (film.trailer || 0) + (film.clean || 0);
          endDate = new Date(rec.start.getTime() + total * 60000);
        } else {
          endDate = new Date(rec.start);
        }
      }
      byAud[audId].push({
        start: rec.start instanceof Date ? rec.start : new Date(rec.start),
        end: endDate,
        audName: rec.audName || ''
      });
    });
    // Use current first show time as operating window start
    const state = ShowtimeState.state || {};
    const firstHM = (state && state.firstShowHM) || '07:00';
    const windowStartRaw = ShowtimeState.dtFromHM ? ShowtimeState.dtFromHM(firstHM) : new Date();
    Object.keys(byAud).forEach(audId => {
      const list = byAud[audId];
      list.sort((a,b) => normalizeDateForGap(a.start) - normalizeDateForGap(b.start));
      if (!list.length) return;
      const audName = list[0].audName || `Aud ${audId}`;
      // Late first slot
      const windowStart = normalizeDateForGap(windowStartRaw);
      const firstStart = normalizeDateForGap(list[0].start);
      const diffFirst = (firstStart - windowStart) / 60000;
      if (diffFirst >= FIT_SLOT_MIN) {
        const startDisp = ShowtimeState.to12 ? ShowtimeState.to12(windowStartRaw) : '';
        const endDisp = ShowtimeState.to12 ? ShowtimeState.to12(list[0].start) : '';
        const durationStr = formatDuration(diffFirst);
        issues.push({
          audName,
          type: 'late',
          message: `${audName}: slot before first show from ${startDisp} to ${endDisp} (${durationStr})`,
          minutes: diffFirst
        });
      }
      // Consecutive gaps within the auditorium
      for (let i = 0; i < list.length - 1; i++) {
        const currEnd = normalizeDateForGap(list[i].end);
        const nextStart = normalizeDateForGap(list[i + 1].start);
        const gapMin = (nextStart - currEnd) / 60000;
        if (gapMin >= GAP_THRESHOLD_MIN) {
          const startDisp = ShowtimeState.to12 ? ShowtimeState.to12(list[i].end) : '';
          const endDisp = ShowtimeState.to12 ? ShowtimeState.to12(list[i + 1].start) : '';
          const durationStr = formatDuration(gapMin);
          const type = gapMin >= GAP_HUGE_MIN ? 'huge' : 'gap';
          issues.push({
            audName,
            type,
            message: `${audName}: gap from ${startDisp} to ${endDisp} (${durationStr})`,
            minutes: gapMin
          });
        }
      }
    });
    // Sort by longest duration first
    issues.sort((a, b) => b.minutes - a.minutes);
    return issues;
  }

  /**
   * Update all tabbed charts.  This function reads the current shows from
   * ShowtimeState, aggregates data and updates or creates the charts in
   * each tab.  It must only be called once Chart.js has loaded.
   */
  function updateCharts() {
    const shows = ShowtimeState.getAllShows ? (ShowtimeState.getAllShows() || []) : [];
    // Update the compact Gantt panel with the latest shows.  This call
    // precedes chart computations so that the Gantt can render even if
    // charts are hidden.  The function handles empty datasets and
    // missing containers gracefully.
    try {
      renderMiniGantt(shows);
    } catch (_) {
      // Ignore errors from Gantt rendering to avoid breaking chart updates
    }
    // Aggregate counts by film and auditorium
    const filmCounts = {};
    const audCounts = {};
    shows.forEach(rec => {
      const fName = rec.filmTitle || 'Unknown';
      filmCounts[fName] = (filmCounts[fName] || 0) + 1;
      const aName = rec.audName || 'Unassigned';
      audCounts[aName] = (audCounts[aName] || 0) + 1;
    });
    // Sort entries and limit to top categories
    function limitEntries(obj) {
      const entries = Object.entries(obj).sort((a,b) => b[1] - a[1]);
      if (entries.length <= MAX_BAR_CATEGORIES) return entries;
      const limited = entries.slice(0, MAX_BAR_CATEGORIES);
      const otherTotal = entries.slice(MAX_BAR_CATEGORIES).reduce((sum, [, val]) => sum + val, 0);
      limited.push(['Other', otherTotal]);
      return limited;
    }
    const filmEntries = limitEntries(filmCounts);
    const audEntries = limitEntries(audCounts);
    const filmLabels = filmEntries.map(([n]) => n);
    const filmData = filmEntries.map(([, v]) => v);
    const audLabels = audEntries.map(([n]) => n);
    const audData = audEntries.map(([, v]) => v);
    // Time distributions (start, end, seats)
    const timeDist = computeTimeDistribution(shows);
    // Utilisation per auditorium (percentage of available window used)
    const utilLabels = [];
    const utilVals = [];
    try {
      const state = ShowtimeState.state;
      let firstHM = (state && state.firstShowHM) || '07:00';
      let lastHM = (state && state.lastShowHM) || '23:00';
      const dateIso2 = ShowtimeState.getCurrentDate && ShowtimeState.getCurrentDate();
      if (dateIso2 && state.scheduleByDate && state.scheduleByDate[dateIso2]) {
        const entry = state.scheduleByDate[dateIso2];
        firstHM = entry.firstShowHM || firstHM;
        lastHM = entry.lastShowHM || lastHM;
      }
      const firstDate = ShowtimeState.dtFromHM(firstHM);
      const lastDate = ShowtimeState.dtFromHM(lastHM);
      let available = (lastDate - firstDate) / 60000;
      if (available <= 0) available += 24 * 60;
      Object.keys(audCounts).forEach(name => {
        utilLabels.push(name);
        utilVals.push(0);
      });
      const idxMap = {};
      utilLabels.forEach((name, idx) => { idxMap[name] = idx; });
      shows.forEach(rec => {
        const name = rec.audName || 'Unassigned';
        const i = idxMap[name];
        if (i == null) return;
        const start = rec.start instanceof Date ? rec.start : new Date(rec.start);
        const end = rec.end instanceof Date ? rec.end : new Date(rec.end);
        let duration = (end - start) / 60000;
        if (duration < 0) duration = 0;
        utilVals[i] += duration;
      });
      utilVals.forEach((mins, idx) => {
        utilVals[idx] = available > 0 ? Math.min(100, (mins / available) * 100) : 0;
      });
    } catch (_) {}
    // Limit utilisation categories as well
    const utilEntries = utilLabels.map((n, i) => [n, utilVals[i]]).sort((a,b) => b[1] - a[1]);
    const utilLimited = utilEntries.length > MAX_BAR_CATEGORIES ?
      utilEntries.slice(0, MAX_BAR_CATEGORIES).concat([[ 'Other', utilEntries.slice(MAX_BAR_CATEGORIES).reduce((sum, [, v]) => sum + v, 0) ]]) :
      utilEntries;
    const utilLabelsLimited = utilLimited.map(([n]) => n);
    const utilValsLimited = utilLimited.map(([, v]) => v);
    // Flagged issue counts
    const issueCounts = computeFlaggedCounts(shows);
    // Determine brand colours from CSS variables
    const rootStyle = getComputedStyle(document.documentElement);
    let primary = rootStyle.getPropertyValue('--brand-from').trim();
    if (!primary) primary = '#3b82f6';
    const lighten = (hex, percent) => {
      const h = hex.replace('#','');
      const r = parseInt(h.substr(0,2), 16);
      const g = parseInt(h.substr(2,2), 16);
      const b = parseInt(h.substr(4,2), 16);
      const nr = Math.min(255, Math.round(r + (255 - r) * percent / 100));
      const ng = Math.min(255, Math.round(g + (255 - g) * percent / 100));
      const nb = Math.min(255, Math.round(b + (255 - b) * percent / 100));
      return '#' + [nr,ng,nb].map(x => x.toString(16).padStart(2,'0')).join('');
    };
    const darken = (hex, percent) => {
      const h = hex.replace('#','');
      const r = parseInt(h.substr(0,2), 16);
      const g = parseInt(h.substr(2,2), 16);
      const b = parseInt(h.substr(4,2), 16);
      const nr = Math.max(0, Math.round(r - r * percent / 100));
      const ng = Math.max(0, Math.round(g - g * percent / 100));
      const nb = Math.max(0, Math.round(b - b * percent / 100));
      return '#' + [nr,ng,nb].map(x => x.toString(16).padStart(2,'0')).join('');
    };
    const colors = {
      film: primary,
      aud: lighten(primary, 20),
      timeStart: darken(primary, 10),
      timeEnd: lighten(primary, 30),
      seats: lighten(primary, 40),
      util: darken(primary, 20)
    };
    // Build or update film chart
    const filmCanvas = document.getElementById('dashboardFilmTabCanvas');
    if (filmCanvas) {
      const ctx = filmCanvas.getContext('2d');
      if (filmChart) {
        filmChart.data.labels = filmLabels;
        filmChart.data.datasets[0].data = filmData;
        filmChart.update();
      } else {
        filmChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: filmLabels,
            datasets: [{ label: 'Shows', data: filmData, backgroundColor: colors.film }]
          },
          options: {
            // Disable responsiveness so the chart respects the explicit canvas size
            responsive: false,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
              x: { beginAtZero: true },
              y: { ticks: { autoSkip: false } }
            }
          }
        });
      }
    }
    // Build or update auditorium chart
    const audCanvas = document.getElementById('dashboardAudTabCanvas');
    if (audCanvas) {
      const ctx = audCanvas.getContext('2d');
      if (audChart) {
        audChart.data.labels = audLabels;
        audChart.data.datasets[0].data = audData;
        audChart.update();
      } else {
        audChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: audLabels,
            datasets: [{ label: 'Shows', data: audData, backgroundColor: colors.aud }]
          },
          options: {
            responsive: false,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
              x: { beginAtZero: true },
              y: { ticks: { autoSkip: false } }
            }
          }
        });
      }
    }
    // Build or update time distribution chart (start vs end vs seats)
    const timeCanvas = document.getElementById('dashboardTimeTabCanvas');
    if (timeCanvas) {
      const ctx = timeCanvas.getContext('2d');
      // Destroy any existing chart to properly reconfigure axes
      if (timeChart) { try { timeChart.destroy(); } catch (_) {} }
      timeChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: timeDist.labels,
          datasets: [
            {
              label: 'Starts',
              data: timeDist.starts,
              borderColor: colors.timeStart,
              backgroundColor: colors.timeStart,
              tension: 0.2,
              fill: false,
              yAxisID: 'y'
            },
            {
              label: 'Ends',
              data: timeDist.ends,
              borderColor: colors.timeEnd,
              backgroundColor: colors.timeEnd,
              tension: 0.2,
              fill: false,
              yAxisID: 'y'
            },
            {
              label: 'Seats',
              data: timeDist.seats,
              borderColor: colors.seats,
              backgroundColor: colors.seats,
              tension: 0.2,
              fill: false,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          responsive: false,
          maintainAspectRatio: false,
          scales: {
            y: {
              type: 'linear',
              position: 'left',
              beginAtZero: true,
              title: { display: true, text: 'Shows' }
            },
            y1: {
              type: 'linear',
              position: 'right',
              beginAtZero: true,
              title: { display: true, text: 'Seats' },
              grid: { drawOnChartArea: false }
            }
          },
          interaction: { intersect: false, mode: 'index' },
          plugins: { legend: { display: true } }
        }
      });
    }
    // Build or update utilisation chart
    const utilCanvas = document.getElementById('dashboardUtilTabCanvas');
    if (utilCanvas) {
      const ctx = utilCanvas.getContext('2d');
      if (utilChart) {
        utilChart.data.labels = utilLabelsLimited;
        utilChart.data.datasets[0].data = utilValsLimited;
        utilChart.update();
      } else {
        utilChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: utilLabelsLimited,
            datasets: [{ label: 'Utilisation (%)', data: utilValsLimited, backgroundColor: colors.util }]
          },
          options: {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                max: 100,
                ticks: {
                  callback: value => value + '%'
                },
                title: { display: true, text: 'Utilisation (%)' }
              }
            },
            plugins: {
              tooltip: {
                callbacks: {
                  label: context => context.parsed.y.toFixed(1) + '%'
                }
              }
            }
          }
        });
      }
    }
    // Update issues summary in the util tab
    const summaryEl = document.getElementById('dashboardUtilIssues');
    if (summaryEl) {
      const parts = [];
      if (issueCounts.late) parts.push(`${issueCounts.late} late`);
      if (issueCounts.huge) parts.push(`${issueCounts.huge} huge gap${issueCounts.huge > 1 ? 's' : ''}`);
      if (issueCounts.gap) parts.push(`${issueCounts.gap} gap${issueCounts.gap > 1 ? 's' : ''}`);
      summaryEl.textContent = parts.length ? parts.join(' \u00b7 ') : 'No issues';
    }

    // Populate the flagged issues tab with detailed messages
    const issuesListEl = document.getElementById('dashboardIssuesList');
    if (issuesListEl) {
      // Clear existing list
      issuesListEl.innerHTML = '';
      const fullIssues = computeFlaggedIssues(shows);
      fullIssues.forEach(issue => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.href = `schedule-grid.html?jump=${encodeURIComponent(issue.audName)}`;
        a.textContent = issue.message;
        let colourClass = '';
        if (issue.type === 'late') {
          colourClass = 'text-blue-800';
        } else if (issue.type === 'gap') {
          colourClass = 'text-yellow-700';
        } else if (issue.type === 'huge') {
          colourClass = 'text-red-700';
        }
        a.className = `${colourClass} underline`;
        a.title = 'View in schedule';
        li.appendChild(a);
        issuesListEl.appendChild(li);
      });
      if (fullIssues.length === 0) {
        const li = document.createElement('li');
        li.className = 'text-green-700';
        li.textContent = 'No downtime or late-first issues detected.';
        issuesListEl.appendChild(li);
      }
    }
    // No need to adjust body padding for the floating popup
  }

  /**
   * Initialise the dashboard bar: insert toggle button, build the bar
   * structure with tabs and attach event listeners.  When the user
   * toggles the bar open, Chart.js is loaded on demand and charts are
   * rendered.  Updating is triggered whenever the date or show window
   * selectors change.
   */
  document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('nav');
    if (!nav) return;
    const controlsContainer = nav.querySelector('.nav-controls') || nav;
    // Avoid inserting multiple toggles
    if (document.getElementById('dashboardBarToggleBtn')) return;
    // Create toggle button
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'dashboardBarToggleBtn';
    toggleBtn.textContent = 'Show Dashboard';
    toggleBtn.className = 'ml-2 px-3 py-1 bg-indigo-700 text-white rounded-lg hover:bg-indigo-800 text-sm';
    controlsContainer.appendChild(toggleBtn);

    // On load, restore the open state from localStorage.  If the user
    // previously had the dashboard bar open, automatically open it
    // immediately.  Use a short timeout to defer until after the bar is
    // attached, ensuring that applyBarState can access required
    // variables.  If localStorage is unavailable or the key is
    // missing, the bar will remain hidden by default.
    let _persistOpen = false;
    try {
      _persistOpen = localStorage.getItem(DASHBAR_OPEN_KEY) === '1';
    } catch (e) {
      _persistOpen = false;
    }
    if (_persistOpen) {
      // Defer to ensure DOM elements exist and Chart.js can be loaded.
      setTimeout(() => applyBarState(true), 0);
    }
    // Create bar container.  Instead of spanning the full width of the
    // page, this dashboard widget floats near the bottom-left of the
    // viewport.  The user can move it by dragging the header and
    // resize it via native browser handles.  Overflow is set to
    // "auto" so the resize handles appear and content can adjust.
    const bar = document.createElement('div');
    bar.id = 'dashboardBar';
    bar.className = 'hidden fixed bg-white border border-gray-300 shadow-lg z-50';
    // Default positioning and dimensions for the floating bar
    bar.style.left = '20px';
    bar.style.bottom = '20px';
    bar.style.width = '420px';
    bar.style.height = '320px';
    bar.style.resize = 'both';
    bar.style.overflow = 'auto';
    // Header with title and close button
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center grad-header px-4 py-2';
    const title = document.createElement('span');
    title.textContent = 'Dashboard';
    title.className = 'font-semibold text-sm text-white';
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '\u00d7';
    closeBtn.className = 'text-white hover:text-gray-200';
    closeBtn.addEventListener('click', () => applyBarState(false));
    header.appendChild(title);
    header.appendChild(closeBtn);
    bar.appendChild(header);

    // Make the bar draggable by dragging the header.  This helper sets up
    // listeners on the header to update the bar’s left and bottom
    // position based on mouse movement.  We store the original
    // positions and adjust them as the cursor moves.  Dragging is
    // disabled when the mouse button is released.
    (function enableDrag(el, handle) {
      handle.style.cursor = 'move';
      let isDragging = false;
      let startX, startY, origLeft, origBottom;
      function onMove(ev) {
        if (!isDragging) return;
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        // Update left and bottom positions.  Moving up (negative dy)
        // increases the bottom offset, while moving down decreases it.
        el.style.left = (origLeft + dx) + 'px';
        el.style.bottom = (origBottom - dy) + 'px';
      }
      function onUp() {
        if (!isDragging) return;
        isDragging = false;
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      }
      handle.addEventListener('mousedown', ev => {
        ev.preventDefault();
        isDragging = true;
        startX = ev.clientX;
        startY = ev.clientY;
        origLeft = parseFloat(el.style.left) || 0;
        origBottom = parseFloat(el.style.bottom) || 0;
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    })(bar, header);
    // Tabs header
    const tabHeader = document.createElement('div');
    tabHeader.className = 'flex border-b border-gray-300 text-sm';
    // Tab definitions
    const tabs = [
      { id: 'film', label: 'Films' },
      { id: 'aud', label: 'Auditoria' },
      { id: 'time', label: 'Start/End' },
      { id: 'util', label: 'Utilisation' },
      { id: 'issues', label: 'Issues' },
      { id: 'gantt', label: 'Gantt' }
    ];
    // Keep references to tab buttons so we can update styles programmatically
    const tabButtons = [];
    // Define a helper to switch active tabs and persist the choice.  When
    // invoked, this function updates the button appearance, shows the
    // corresponding panel, hides others, resizes charts, and stores the
    // selected tab id.  It gracefully handles missing panels.
    function setActiveTab(tabId) {
      tabButtons.forEach(btn => {
        const isActive = btn.dataset.tabId === tabId;
        btn.classList.toggle('font-semibold', isActive);
        btn.classList.toggle('bg-gray-100', isActive);
      });
      tabs.forEach(t => {
        const panel = document.getElementById('dashboardTabPanel-' + t.id);
        if (panel) {
          if (t.id === tabId) {
            panel.classList.remove('hidden');
          } else {
            panel.classList.add('hidden');
          }
        }
      });
      // Persist the selected tab id.  If localStorage is unavailable, ignore.
      try {
        localStorage.setItem(DASHBAR_TAB_KEY, tabId);
      } catch (_) {}
      // Resize the chart in the newly visible panel after a short delay
      setTimeout(() => {
        if (tabId === 'film' && filmChart) filmChart.resize();
        if (tabId === 'aud' && audChart) audChart.resize();
        if (tabId === 'time' && timeChart) timeChart.resize();
        if (tabId === 'util' && utilChart) utilChart.resize();
      }, 50);
    }
    tabs.forEach((tab, idx) => {
      const btn = document.createElement('button');
      btn.textContent = tab.label;
      btn.dataset.tabId = tab.id;
      btn.className = 'px-4 py-2 focus:outline-none border-r border-gray-200';
      tabButtons.push(btn);
      btn.addEventListener('click', () => {
        setActiveTab(tab.id);
      });
      tabHeader.appendChild(btn);
    });
    bar.appendChild(tabHeader);
    // Content area
    const content = document.createElement('div');
    content.className = 'p-4 h-full overflow-hidden';
    // Film tab panel
    const filmPanel = document.createElement('div');
    filmPanel.id = 'dashboardTabPanel-film';
    filmPanel.className = '';
    // Fix the height of each tab panel to match its canvas so it never grows
    filmPanel.style.height = '220px';
    // Add slight padding at the bottom to prevent chart cut‑off
    filmPanel.style.paddingBottom = '10px';
    const filmCanvas = document.createElement('canvas');
    filmCanvas.id = 'dashboardFilmTabCanvas';
    filmCanvas.setAttribute('height','220');
    filmPanel.appendChild(filmCanvas);
    content.appendChild(filmPanel);
    // Auditorium tab panel
    const audPanel = document.createElement('div');
    audPanel.id = 'dashboardTabPanel-aud';
    audPanel.className = 'hidden';
    audPanel.style.height = '220px';
    audPanel.style.paddingBottom = '10px';
    const audCanvas = document.createElement('canvas');
    audCanvas.id = 'dashboardAudTabCanvas';
    audCanvas.setAttribute('height','220');
    audPanel.appendChild(audCanvas);
    content.appendChild(audPanel);
    // Time tab panel
    const timePanel = document.createElement('div');
    timePanel.id = 'dashboardTabPanel-time';
    timePanel.className = 'hidden';
    timePanel.style.height = '220px';
    timePanel.style.paddingBottom = '10px';
    const timeCanvas = document.createElement('canvas');
    timeCanvas.id = 'dashboardTimeTabCanvas';
    timeCanvas.setAttribute('height','220');
    timePanel.appendChild(timeCanvas);
    content.appendChild(timePanel);
    // Utilisation tab panel
    const utilPanel = document.createElement('div');
    utilPanel.id = 'dashboardTabPanel-util';
    utilPanel.className = 'hidden flex flex-col';
    // Slightly taller to accommodate the summary text below the chart
    utilPanel.style.height = '220px';
    utilPanel.style.paddingBottom = '10px';
    const utilCanvas = document.createElement('canvas');
    utilCanvas.id = 'dashboardUtilTabCanvas';
    utilCanvas.setAttribute('height','180');
    utilPanel.appendChild(utilCanvas);
    const utilIssues = document.createElement('div');
    utilIssues.id = 'dashboardUtilIssues';
    utilIssues.className = 'text-sm mt-2';
    utilPanel.appendChild(utilIssues);
    content.appendChild(utilPanel);

    // Issues tab panel: displays a list of downtime gaps and late-first slots
    const issuesPanel = document.createElement('div');
    issuesPanel.id = 'dashboardTabPanel-issues';
    issuesPanel.className = 'hidden';
    // Fixed height and bottom padding like other panels; allow vertical scrolling within
    issuesPanel.style.height = '220px';
    issuesPanel.style.paddingBottom = '10px';
    issuesPanel.style.overflowY = 'auto';
    const issuesList = document.createElement('ul');
    issuesList.id = 'dashboardIssuesList';
    issuesList.className = 'list-disc pl-5 space-y-1 text-sm';
    issuesPanel.appendChild(issuesList);
    content.appendChild(issuesPanel);

    // Gantt tab panel: displays a compact Gantt timeline for the current date
    const ganttPanel = document.createElement('div');
    ganttPanel.id = 'dashboardTabPanel-gantt';
    ganttPanel.className = 'hidden';
    // Fixed height similar to other panels; horizontal scrolling is handled in the render function
    ganttPanel.style.height = '220px';
    ganttPanel.style.paddingBottom = '10px';
    content.appendChild(ganttPanel);
    bar.appendChild(content);
    document.body.appendChild(bar);
    // Restore last selected tab from localStorage or default to first tab.
    (function restoreTab() {
      let savedTabId = null;
      try {
        savedTabId = localStorage.getItem(DASHBAR_TAB_KEY);
      } catch (_) {
        savedTabId = null;
      }
      // Validate saved tab; if invalid or missing, use the first defined tab
      if (!savedTabId || !tabs.some(t => t.id === savedTabId)) {
        savedTabId = tabs[0].id;
      }
      // Defer until next tick so tab buttons are appended
      setTimeout(() => setActiveTab(savedTabId), 0);
    })();

    // Observe changes to the bar’s size and update charts accordingly.  When
    // the user resizes the floating popup, Chart.js needs to recalculate
    // its dimensions.  ResizeObserver provides a callback when the
    // element’s size changes.
    if (typeof ResizeObserver !== 'undefined') {
      const resizeObserver = new ResizeObserver(() => {
        if (bar.classList.contains('hidden')) return;
        if (filmChart) filmChart.resize();
        if (audChart) audChart.resize();
        if (timeChart) timeChart.resize();
        if (utilChart) utilChart.resize();
      });
      resizeObserver.observe(bar);
    }
    // Manage bar state
    function applyBarState(open) {
      if (open) {
        bar.classList.remove('hidden');
        toggleBtn.textContent = 'Hide Dashboard';
        // Remember open state in localStorage.  Wrapping in try/catch
        // guards against storage being unavailable (e.g. private mode).
        try {
          localStorage.setItem(DASHBAR_OPEN_KEY, '1');
        } catch (e) {}
        // Load Chart.js and update charts whenever the bar becomes visible.
        loadChartJs().then(() => {
          updateCharts();
        });
      } else {
        bar.classList.add('hidden');
        toggleBtn.textContent = 'Show Dashboard';
        // Persist closed state
        try {
          localStorage.setItem(DASHBAR_OPEN_KEY, '0');
        } catch (e) {}
      }
    }
    toggleBtn.addEventListener('click', () => {
      const hidden = bar.classList.contains('hidden');
      applyBarState(hidden);
    });
    // Listen for changes to global controls (date, first/last show) and
    // update charts when schedule state changes.
    function attachControlListeners() {
      const dateInput = document.getElementById('scheduleDateGlobal');
      if (dateInput) dateInput.addEventListener('change', () => updateCharts());
      const firstSel = document.getElementById('firstShowGlobalSelect');
      const lastSel = document.getElementById('lastShowGlobalSelect');
      if (firstSel) firstSel.addEventListener('change', () => updateCharts());
      if (lastSel) lastSel.addEventListener('change', () => updateCharts());
    }
    attachControlListeners();

    // Register listeners for application events so the dashboard bar
    // updates automatically whenever the schedule state changes or the
    // selected date changes.  These events are dispatched from
    // app.js when data is saved or the date is switched.  In addition,
    // listen to filmHighlightChange to update charts based on the
    // currently highlighted film.  Only update if the bar is
    // currently visible to avoid unnecessary work.
    window.addEventListener('showtimeStateUpdated', () => {
      if (!bar.classList.contains('hidden')) updateCharts();
    });
    window.addEventListener('showtimeDateChanged', () => {
      if (!bar.classList.contains('hidden')) updateCharts();
    });
    window.addEventListener('filmHighlightChange', () => {
      if (!bar.classList.contains('hidden')) updateCharts();
    });
  });
})();